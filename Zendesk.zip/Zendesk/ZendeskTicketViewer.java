/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ZendeskTicketViewer;

import java.util.Scanner;
import org.json.JSONArray;



/**
 *
 * @author Anubhuti Dayal
 */
public class ZendeskTicketViewer {
    
    
    
    public static int getInteger(Scanner input)
    {
            while (input.hasNextInt() == false)
            {
                //System.out.println("invalid input");
                DisplayMsg(0);
                input.next();
                continue;
            }
            return(input.nextInt());

    }

    /**
     * @param args the command line arguments
     */
    
   
    public static void main(String args[]) {
        
        Scanner input = new Scanner(System.in);
        int sel;
        int Pagestartcnt=0;
        int PageSize=25;
        int PageEndcnt=0;
        int tktnumber;
        JSONArray arr=null;
        
        
        GetAPIJSONData getJSON=new GetAPIJSONData();
        ViewTicket vwtkt=new ViewTicket();
        System.out.println("Welcome to Zendesk Ticket Viewer");
        while(true)
        {
            System.out.println("Type '1' to view all available options or '0' to exit");
            sel = getInteger(input);
            if (sel == 0)
            {
                break;
            }
            else if (sel == 1)
            { 
                DisplayMsg(1); 
                System.out.println("1)Press 1 to view tickets\n2)Press 2 to view a ticket\n3)Press 0 to go back to main menu");
        
                sel = getInteger(input);
                if (sel == 0)
                {
                    break;
                }
                else if (sel == 1){  
                    DisplayMsg(4);
                    arr=getJSON.GetJSONstrData(sel);
                    int numPages = (int) Math.ceil((double)arr.length() / (double)PageSize);
                    for (int pageNum = 0; pageNum <= numPages;)
                    {
                       Pagestartcnt= pageNum * PageSize;
                       PageEndcnt= Math.min(++pageNum * PageSize, arr.length());
                        if(pageNum <= numPages)
                           {
                            vwtkt.ViewTicketList(arr,Pagestartcnt,PageEndcnt);
                            System.out.println("-----------------------------------------------------------------------------------------------");
                            System.out.printf("Page%d   Total records count :"+arr.length()+"\n-----------------------------\n",pageNum);
                            
                            if(pageNum < numPages)
                            {
                            DisplayMsg(1); 
                            System.out.println("1)Press 2 to view a ticket\n2)Press 3 to view next page tickets\n3)Press 0 to go back to main menu");
        
                            sel = getInteger(input);
                                    if (sel == 0)
                                    {
                                        break;
                                    }
                                    else if (sel == 2)
                                    {
                                        DisplayMsg(3);
                                        tktnumber= getInteger(input);
                                        
                                        if(tktnumber==0 || tktnumber<0 ){
                                         DisplayMsg(0); 
                                         break;

                                        }
                                        else{
                                        DisplayMsg(4);
                                        arr=getJSON.GetJSONstrData(tktnumber);
                                        if(arr.length() != 0)
                                        {
                                        vwtkt.ViewTicket(arr);
                                        break;
                                        }
                                        else
                                           DisplayMsg(5); 
                                        }
                                    }
                                    else if (sel == 3)
                                    {      
                                        continue;
                                    }
                                    else
                                    {
                                         DisplayMsg(0);
                                         break;
                                    }
                               }
                            }
                        else
                            {
                                System.out.println("All Records Displayed, Returning to Main Menu !! ");
                                break;
                            }
                    }
                }   
                
                else if (sel == 2)
                {
                    
                    DisplayMsg(3);
                    tktnumber= getInteger(input);
                    //int maxid=arr.getJSONObject(arr.length()-1).optInt("id");
                    if(tktnumber==0 || tktnumber<0 ){
                     DisplayMsg(0); 
                     
                    }
                    else{
                    DisplayMsg(4);
                    arr=getJSON.GetJSONstrData(tktnumber);
                    if(arr.length() != 0)
                                        {
                        vwtkt.ViewTicket(arr);
                        }
                    else
                       DisplayMsg(5); 
                    }
                }
                else
                    {
                         DisplayMsg(0);
                    }
            }
       else
            {
                 DisplayMsg(0);
            }
            
        }
    }
    
    public static void DisplayMsg(int num)
    {
        if(num ==0)
            System.out.println("Please enter valid input");
        if(num ==1)
          {
            System.out.println("Select view options");
            }  
        
         if(num ==3) 
             System.out.println("Enter Ticket Number");
         if(num ==4)
            System.out.println("Please Wait !");
         if(num ==5)
            System.out.println("This Ticket number doesn't exist , Please try again");
    }

    
   
    
}
