/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ZendeskTicketViewer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 *  @author Anubhuti Dayal
 */
public class ViewTicket {
    
               private String strcreated_at ;
               private String strsubject ;
               private String strDescription ;
               private int intassignee_id;
               private JSONObject jsonObject;
               
               
               
               
      //Prints single ticket details        
     public void ViewTicket(JSONArray arr) {
        try
        {
            if (arr != null)
            {
                 jsonObject = arr.getJSONObject(0);
                 intassignee_id = jsonObject.optInt("id");
                 strcreated_at = jsonObject.optString("created_at");
                 strsubject = jsonObject.optString("subject");
                 strDescription = jsonObject.optString("description");
                 if(strcreated_at != "" && strsubject !="" && strDescription != "")
                System.out.println("\nId :" +intassignee_id+"\nSubject :" +strsubject+"\nCreated at:" +strcreated_at+"\n-------------------------------------------\n"+strDescription+"\n-------------------------------------------");
                else
                 {
                     System.out.println("PLease enter valid ticket number");
                     
                   }
                     
        }
        }
        catch(JSONException ex )
        {
               System.out.println("Oops ! Something is not right, Please retry! ");
       
        }
        catch(Exception ex )
        {
               System.out.println("Oops ! Something is not right , Please retry");
       
        }
      }

        //Prints Ticket Lists   
     public void ViewTicketList(JSONArray arr,int Pagestartcnt,int PageEndcnt){       
         
        try
        {
            if (arr != null){
            System.out.println("\n" + "Assignee id           Created at           Subject           Description");
            System.out.println("\n" + "--------------------------------------------------------------------------------------------");
             for (int i = Pagestartcnt; i < PageEndcnt; i++)
               {
                     jsonObject = arr.getJSONObject(i);
                     intassignee_id = jsonObject.optInt("id");
                     strcreated_at = jsonObject.optString("created_at");
                     strsubject = jsonObject.optString("subject");
                     strDescription = jsonObject.optString("description");
                      if(strcreated_at != "" && strsubject !="" && strDescription != "")
                    System.out.println(intassignee_id+"        "+strcreated_at +"        "+strsubject.substring(0, 14) +"       "+strDescription.substring(0, 20));
               }
        }
        }
        catch(JSONException ex )
        {
               System.out.println("Oops ! Network Connection is lost");
       
        }
        catch(Exception ex )
        {
               System.out.println("Oops ! Something is not right , Please retry");
       
        }
    }

    
    
    
    
}
