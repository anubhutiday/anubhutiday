/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ZendeskTicketViewer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Anubhuti Dayal
 */
public class GetAPIJSONData {
    
    //Get Zendesk API data from Tickets API with 2 options below
    //API Data for All Ticket 
    //API Data for a specific Ticket 
    //returns the result in JSONArray
    
    static JSONArray GetJSONstrData(int sel) {
            String output;
            String JSONstr="";
            String strurl="";
            JSONArray arr=null;
        try
        {
            strurl="https://zccstudents8809.zendesk.com/api/v2/";
           if(sel == 1)
               strurl=strurl+"tickets.json";
           else
               strurl=strurl+"tickets/show_many.json?ids="+String.valueOf(sel);
            
            URL url = new URL(strurl);     
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Authorization", "Basic YW51Ymh1dGkuZGF5QGdtYWlsLmNvbTpEZWNAMjAxMw==");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Oops ! Network Connection is lost : Please try again later");
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);
             while ((output = br.readLine()) != null) {
               JSONstr=output;
            } 
            JSONObject obj = new JSONObject(JSONstr);
            arr = obj.getJSONArray("tickets");
            conn.disconnect();
            
        } 
        catch (IOException | RuntimeException e) {
            System.out.println("Oops ! Network Connection is lost");
            }
        return arr;
        }
    
    
    
    
}
